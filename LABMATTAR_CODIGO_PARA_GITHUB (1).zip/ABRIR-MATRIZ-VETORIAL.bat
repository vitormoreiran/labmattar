@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js nao foi encontrado neste computador.
  echo Instale a versao LTS em https://nodejs.org/ e execute este arquivo novamente.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo.
  echo Preparando a Matriz Vetorial pela primeira vez...
  echo Isso pode levar alguns minutos.
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo A instalacao nao foi concluida. Verifique a conexao com a internet.
    pause
    exit /b 1
  )
)

echo.
echo Abrindo a Matriz Vetorial em http://localhost:5173
echo Mantenha esta janela aberta enquanto estiver usando a ferramenta.
echo Para encerrar, pressione Ctrl+C.
echo.
call npx vite --host 127.0.0.1 --port 5173 --open

pause
