# LABMATTAR — identidade e Matriz Vetorial v72

## O que abre
- `/` — apresentação editorial (redireciona para `/manual.html`)
- `/manual.html` — apresentação de elementos gráficos
- `/editor` — editor Matriz Vetorial v72 completo, adaptado visualmente

## Publicação de prévia
Este é um projeto de código-fonte, ainda não compilado. O ambiente atual não consegue acessar registry.npmjs.org (EAI_AGAIN).

Requisitos: Node.js >=22.13, conexão com npm e Linux com `timeout`, `flock`, `curl`.

1. Suba o conteúdo desta pasta para um repositório privado no GitHub.
2. Configure a compilação em um CI Linux com `npm ci` e `npm run build`.
3. Valide o build antes de publicar. O `vite.config.ts` foi criado para vinext/Sites com plugin Cloudflare, podendo exigir adaptação do destino de deploy.
4. Publique somente em subdomínio/worker de PRÉVIA. Não utilize o Worker da produção labmattar.com.

## Checklist mínimo de teste depois do deploy
- `/` abre o manual; navegação do manual abre `/editor`.
- M + 9 vasos carrega os SVGs oficiais.
- Timeline, correspondências, curvas, salvamento, reimportação.
- Exportar frame SVG, SVG animado e MP4.
- Conferir arquivos exportados e comportamento em desktop/mobile.

A compilação e o deploy NÃO foram concluídos nem validados neste pacote.
